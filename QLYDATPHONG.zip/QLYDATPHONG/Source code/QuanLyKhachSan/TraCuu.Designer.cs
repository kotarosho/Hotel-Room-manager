﻿namespace QuanLyKhachSan
{
    partial class TraCuu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tabTraCuu = new System.Windows.Forms.TabControl();
            this.tabPhong = new System.Windows.Forms.TabPage();
            this.cmbLoaiPhong = new System.Windows.Forms.ComboBox();
            this.btnTimPhong = new System.Windows.Forms.Button();
            this.cmbTinhTrang = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lsvDanhSachPhong = new System.Windows.Forms.ListView();
            this.clnPhong = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clnLoaiPhong = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clnDonGia = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clnTinhTrang = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnMenu = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnThuePhong = new System.Windows.Forms.Button();
            this.tabPhieuThue = new System.Windows.Forms.TabPage();
            this.cmbNamPT = new System.Windows.Forms.ComboBox();
            this.lblNamPT = new System.Windows.Forms.Label();
            this.cmbThangPT = new System.Windows.Forms.ComboBox();
            this.lblThangPT = new System.Windows.Forms.Label();
            this.cmbNgayPT = new System.Windows.Forms.ComboBox();
            this.lblNgayPT = new System.Windows.Forms.Label();
            this.btnMenuPT = new System.Windows.Forms.Button();
            this.btnThoatPT = new System.Windows.Forms.Button();
            this.lsvDanhSachPhieuThue = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnTimPhieuThue = new System.Windows.Forms.Button();
            this.rbtnMaPhieuThue = new System.Windows.Forms.RadioButton();
            this.rbtnNgayThue = new System.Windows.Forms.RadioButton();
            this.txtMaPhieuThue = new System.Windows.Forms.TextBox();
            this.tabHoaDon = new System.Windows.Forms.TabPage();
            this.cmbNamHD = new System.Windows.Forms.ComboBox();
            this.lblNamHD = new System.Windows.Forms.Label();
            this.cmbThangHD = new System.Windows.Forms.ComboBox();
            this.lblThangHD = new System.Windows.Forms.Label();
            this.cmbNgayHD = new System.Windows.Forms.ComboBox();
            this.lblNgayHD = new System.Windows.Forms.Label();
            this.btnMenuHD = new System.Windows.Forms.Button();
            this.btnThoatHD = new System.Windows.Forms.Button();
            this.lsvDanhSachHoaDon = new System.Windows.Forms.ListView();
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnTimHoaDon = new System.Windows.Forms.Button();
            this.rbtnMaHoaDon = new System.Windows.Forms.RadioButton();
            this.rbtnNgayTra = new System.Windows.Forms.RadioButton();
            this.txtMaHoaDon = new System.Windows.Forms.TextBox();
            this.tabBaoCao = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTongDoanhThu = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbNamBC = new System.Windows.Forms.ComboBox();
            this.lblNamBC = new System.Windows.Forms.Label();
            this.cmbThangBC = new System.Windows.Forms.ComboBox();
            this.lblThangBC = new System.Windows.Forms.Label();
            this.btnMenuBC = new System.Windows.Forms.Button();
            this.btnThoatBC = new System.Windows.Forms.Button();
            this.lsvDanhSachBaoCao = new System.Windows.Forms.ListView();
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnTimBaoCao = new System.Windows.Forms.Button();
            this.rbtnMaBaoCao = new System.Windows.Forms.RadioButton();
            this.rbtnThangBaoCao = new System.Windows.Forms.RadioButton();
            this.txtMaBaoCao = new System.Windows.Forms.TextBox();
            this.tabTraCuu.SuspendLayout();
            this.tabPhong.SuspendLayout();
            this.tabPhieuThue.SuspendLayout();
            this.tabHoaDon.SuspendLayout();
            this.tabBaoCao.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Roboto Condensed", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(53, 55);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 41);
            this.label1.TabIndex = 16;
            this.label1.Text = "Tra cứu";
            // 
            // tabTraCuu
            // 
            this.tabTraCuu.Controls.Add(this.tabPhong);
            this.tabTraCuu.Controls.Add(this.tabPhieuThue);
            this.tabTraCuu.Controls.Add(this.tabHoaDon);
            this.tabTraCuu.Controls.Add(this.tabBaoCao);
            this.tabTraCuu.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabTraCuu.Location = new System.Drawing.Point(12, 128);
            this.tabTraCuu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabTraCuu.Name = "tabTraCuu";
            this.tabTraCuu.SelectedIndex = 0;
            this.tabTraCuu.Size = new System.Drawing.Size(957, 629);
            this.tabTraCuu.TabIndex = 28;
            // 
            // tabPhong
            // 
            this.tabPhong.Controls.Add(this.cmbLoaiPhong);
            this.tabPhong.Controls.Add(this.btnTimPhong);
            this.tabPhong.Controls.Add(this.cmbTinhTrang);
            this.tabPhong.Controls.Add(this.label4);
            this.tabPhong.Controls.Add(this.label3);
            this.tabPhong.Controls.Add(this.lsvDanhSachPhong);
            this.tabPhong.Controls.Add(this.btnMenu);
            this.tabPhong.Controls.Add(this.btnThoat);
            this.tabPhong.Controls.Add(this.btnThuePhong);
            this.tabPhong.Location = new System.Drawing.Point(4, 28);
            this.tabPhong.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPhong.Name = "tabPhong";
            this.tabPhong.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPhong.Size = new System.Drawing.Size(949, 597);
            this.tabPhong.TabIndex = 0;
            this.tabPhong.Text = "Tra cứu phòng";
            this.tabPhong.UseVisualStyleBackColor = true;
            // 
            // cmbLoaiPhong
            // 
            this.cmbLoaiPhong.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLoaiPhong.FormattingEnabled = true;
            this.cmbLoaiPhong.Items.AddRange(new object[] {
            "Standard",
            "Superior",
            "Deluxe",
            "Tất cả"});
            this.cmbLoaiPhong.Location = new System.Drawing.Point(153, 39);
            this.cmbLoaiPhong.Margin = new System.Windows.Forms.Padding(4);
            this.cmbLoaiPhong.Name = "cmbLoaiPhong";
            this.cmbLoaiPhong.Size = new System.Drawing.Size(223, 27);
            this.cmbLoaiPhong.TabIndex = 35;
            // 
            // btnTimPhong
            // 
            this.btnTimPhong.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(161)))), ((int)(((byte)(130)))));
            this.btnTimPhong.FlatAppearance.BorderSize = 0;
            this.btnTimPhong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimPhong.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimPhong.ForeColor = System.Drawing.Color.White;
            this.btnTimPhong.Location = new System.Drawing.Point(809, 142);
            this.btnTimPhong.Margin = new System.Windows.Forms.Padding(4);
            this.btnTimPhong.Name = "btnTimPhong";
            this.btnTimPhong.Size = new System.Drawing.Size(100, 46);
            this.btnTimPhong.TabIndex = 36;
            this.btnTimPhong.Text = "Tìm";
            this.btnTimPhong.UseVisualStyleBackColor = false;
            this.btnTimPhong.Click += new System.EventHandler(this.btnTimPhong_Click);
            // 
            // cmbTinhTrang
            // 
            this.cmbTinhTrang.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTinhTrang.FormattingEnabled = true;
            this.cmbTinhTrang.Items.AddRange(new object[] {
            "Phòng trống",
            "Phòng kín",
            "Tất cả"});
            this.cmbTinhTrang.Location = new System.Drawing.Point(153, 103);
            this.cmbTinhTrang.Margin = new System.Windows.Forms.Padding(4);
            this.cmbTinhTrang.Name = "cmbTinhTrang";
            this.cmbTinhTrang.Size = new System.Drawing.Size(223, 27);
            this.cmbTinhTrang.TabIndex = 34;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(43, 107);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 19);
            this.label4.TabIndex = 32;
            this.label4.Text = "Tình trạng";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(43, 43);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 19);
            this.label3.TabIndex = 33;
            this.label3.Text = "Loại phòng";
            // 
            // lsvDanhSachPhong
            // 
            this.lsvDanhSachPhong.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clnPhong,
            this.clnLoaiPhong,
            this.clnDonGia,
            this.clnTinhTrang});
            this.lsvDanhSachPhong.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lsvDanhSachPhong.FullRowSelect = true;
            this.lsvDanhSachPhong.GridLines = true;
            this.lsvDanhSachPhong.Location = new System.Drawing.Point(45, 194);
            this.lsvDanhSachPhong.Margin = new System.Windows.Forms.Padding(4);
            this.lsvDanhSachPhong.MultiSelect = false;
            this.lsvDanhSachPhong.Name = "lsvDanhSachPhong";
            this.lsvDanhSachPhong.Size = new System.Drawing.Size(863, 315);
            this.lsvDanhSachPhong.TabIndex = 31;
            this.lsvDanhSachPhong.UseCompatibleStateImageBehavior = false;
            this.lsvDanhSachPhong.View = System.Windows.Forms.View.Details;
            // 
            // clnPhong
            // 
            this.clnPhong.Text = "Phòng";
            this.clnPhong.Width = 140;
            // 
            // clnLoaiPhong
            // 
            this.clnLoaiPhong.Text = "Loại phòng";
            this.clnLoaiPhong.Width = 140;
            // 
            // clnDonGia
            // 
            this.clnDonGia.Text = "Đơn giá";
            this.clnDonGia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.clnDonGia.Width = 140;
            // 
            // clnTinhTrang
            // 
            this.clnTinhTrang.Text = "Tình trạng";
            this.clnTinhTrang.Width = 140;
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnMenu.FlatAppearance.BorderSize = 0;
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenu.ForeColor = System.Drawing.Color.Gray;
            this.btnMenu.Location = new System.Drawing.Point(45, 532);
            this.btnMenu.Margin = new System.Windows.Forms.Padding(4);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(168, 46);
            this.btnMenu.TabIndex = 30;
            this.btnMenu.Text = "Quay lại ";
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnThoat.FlatAppearance.BorderSize = 0;
            this.btnThoat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThoat.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.ForeColor = System.Drawing.Color.Gray;
            this.btnThoat.Location = new System.Drawing.Point(809, 532);
            this.btnThoat.Margin = new System.Windows.Forms.Padding(4);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(100, 46);
            this.btnThoat.TabIndex = 28;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = false;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnThuePhong
            // 
            this.btnThuePhong.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(161)))), ((int)(((byte)(130)))));
            this.btnThuePhong.FlatAppearance.BorderSize = 0;
            this.btnThuePhong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThuePhong.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThuePhong.ForeColor = System.Drawing.Color.White;
            this.btnThuePhong.Location = new System.Drawing.Point(656, 532);
            this.btnThuePhong.Margin = new System.Windows.Forms.Padding(4);
            this.btnThuePhong.Name = "btnThuePhong";
            this.btnThuePhong.Size = new System.Drawing.Size(145, 46);
            this.btnThuePhong.TabIndex = 29;
            this.btnThuePhong.Text = "Thuê phòng";
            this.btnThuePhong.UseVisualStyleBackColor = false;
            this.btnThuePhong.Click += new System.EventHandler(this.btnThuePhong_Click);
            // 
            // tabPhieuThue
            // 
            this.tabPhieuThue.Controls.Add(this.cmbNamPT);
            this.tabPhieuThue.Controls.Add(this.lblNamPT);
            this.tabPhieuThue.Controls.Add(this.cmbThangPT);
            this.tabPhieuThue.Controls.Add(this.lblThangPT);
            this.tabPhieuThue.Controls.Add(this.cmbNgayPT);
            this.tabPhieuThue.Controls.Add(this.lblNgayPT);
            this.tabPhieuThue.Controls.Add(this.btnMenuPT);
            this.tabPhieuThue.Controls.Add(this.btnThoatPT);
            this.tabPhieuThue.Controls.Add(this.lsvDanhSachPhieuThue);
            this.tabPhieuThue.Controls.Add(this.btnTimPhieuThue);
            this.tabPhieuThue.Controls.Add(this.rbtnMaPhieuThue);
            this.tabPhieuThue.Controls.Add(this.rbtnNgayThue);
            this.tabPhieuThue.Controls.Add(this.txtMaPhieuThue);
            this.tabPhieuThue.Location = new System.Drawing.Point(4, 28);
            this.tabPhieuThue.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPhieuThue.Name = "tabPhieuThue";
            this.tabPhieuThue.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPhieuThue.Size = new System.Drawing.Size(949, 597);
            this.tabPhieuThue.TabIndex = 1;
            this.tabPhieuThue.Text = "Tra cứu phiếu thuê";
            this.tabPhieuThue.UseVisualStyleBackColor = true;
            // 
            // cmbNamPT
            // 
            this.cmbNamPT.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbNamPT.FormattingEnabled = true;
            this.cmbNamPT.Items.AddRange(new object[] {
            "2018",
            "2019",
            "2020",
            "2021",
            "2022",
            "2023",
            "2024",
            "2025"});
            this.cmbNamPT.Location = new System.Drawing.Point(740, 44);
            this.cmbNamPT.Margin = new System.Windows.Forms.Padding(4);
            this.cmbNamPT.Name = "cmbNamPT";
            this.cmbNamPT.Size = new System.Drawing.Size(79, 27);
            this.cmbNamPT.TabIndex = 114;
            // 
            // lblNamPT
            // 
            this.lblNamPT.AutoSize = true;
            this.lblNamPT.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNamPT.Location = new System.Drawing.Point(677, 48);
            this.lblNamPT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNamPT.Name = "lblNamPT";
            this.lblNamPT.Size = new System.Drawing.Size(42, 19);
            this.lblNamPT.TabIndex = 113;
            this.lblNamPT.Text = "Năm";
            // 
            // cmbThangPT
            // 
            this.cmbThangPT.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbThangPT.FormattingEnabled = true;
            this.cmbThangPT.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cmbThangPT.Location = new System.Drawing.Point(529, 44);
            this.cmbThangPT.Margin = new System.Windows.Forms.Padding(4);
            this.cmbThangPT.Name = "cmbThangPT";
            this.cmbThangPT.Size = new System.Drawing.Size(79, 27);
            this.cmbThangPT.TabIndex = 112;
            // 
            // lblThangPT
            // 
            this.lblThangPT.AutoSize = true;
            this.lblThangPT.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThangPT.Location = new System.Drawing.Point(459, 48);
            this.lblThangPT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblThangPT.Name = "lblThangPT";
            this.lblThangPT.Size = new System.Drawing.Size(54, 19);
            this.lblThangPT.TabIndex = 111;
            this.lblThangPT.Text = "Tháng";
            // 
            // cmbNgayPT
            // 
            this.cmbNgayPT.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbNgayPT.FormattingEnabled = true;
            this.cmbNgayPT.Items.AddRange(new object[] {
            "--",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.cmbNgayPT.Location = new System.Drawing.Point(317, 44);
            this.cmbNgayPT.Margin = new System.Windows.Forms.Padding(4);
            this.cmbNgayPT.Name = "cmbNgayPT";
            this.cmbNgayPT.Size = new System.Drawing.Size(79, 27);
            this.cmbNgayPT.TabIndex = 110;
            // 
            // lblNgayPT
            // 
            this.lblNgayPT.AutoSize = true;
            this.lblNgayPT.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNgayPT.Location = new System.Drawing.Point(245, 48);
            this.lblNgayPT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNgayPT.Name = "lblNgayPT";
            this.lblNgayPT.Size = new System.Drawing.Size(47, 19);
            this.lblNgayPT.TabIndex = 109;
            this.lblNgayPT.Text = "Ngày";
            // 
            // btnMenuPT
            // 
            this.btnMenuPT.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnMenuPT.FlatAppearance.BorderSize = 0;
            this.btnMenuPT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuPT.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuPT.ForeColor = System.Drawing.Color.Gray;
            this.btnMenuPT.Location = new System.Drawing.Point(45, 532);
            this.btnMenuPT.Margin = new System.Windows.Forms.Padding(4);
            this.btnMenuPT.Name = "btnMenuPT";
            this.btnMenuPT.Size = new System.Drawing.Size(168, 46);
            this.btnMenuPT.TabIndex = 108;
            this.btnMenuPT.Text = "Quay lại menu";
            this.btnMenuPT.UseVisualStyleBackColor = false;
            this.btnMenuPT.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnThoatPT
            // 
            this.btnThoatPT.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnThoatPT.FlatAppearance.BorderSize = 0;
            this.btnThoatPT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThoatPT.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoatPT.ForeColor = System.Drawing.Color.Gray;
            this.btnThoatPT.Location = new System.Drawing.Point(809, 532);
            this.btnThoatPT.Margin = new System.Windows.Forms.Padding(4);
            this.btnThoatPT.Name = "btnThoatPT";
            this.btnThoatPT.Size = new System.Drawing.Size(100, 46);
            this.btnThoatPT.TabIndex = 107;
            this.btnThoatPT.Text = "Thoát";
            this.btnThoatPT.UseVisualStyleBackColor = false;
            this.btnThoatPT.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // lsvDanhSachPhieuThue
            // 
            this.lsvDanhSachPhieuThue.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader4,
            this.columnHeader3,
            this.columnHeader5,
            this.columnHeader6});
            this.lsvDanhSachPhieuThue.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lsvDanhSachPhieuThue.FullRowSelect = true;
            this.lsvDanhSachPhieuThue.GridLines = true;
            this.lsvDanhSachPhieuThue.Location = new System.Drawing.Point(45, 194);
            this.lsvDanhSachPhieuThue.Margin = new System.Windows.Forms.Padding(4);
            this.lsvDanhSachPhieuThue.MultiSelect = false;
            this.lsvDanhSachPhieuThue.Name = "lsvDanhSachPhieuThue";
            this.lsvDanhSachPhieuThue.Size = new System.Drawing.Size(863, 315);
            this.lsvDanhSachPhieuThue.TabIndex = 106;
            this.lsvDanhSachPhieuThue.UseCompatibleStateImageBehavior = false;
            this.lsvDanhSachPhieuThue.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Mã phiếu thuê";
            this.columnHeader1.Width = 127;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Ngày thuê";
            this.columnHeader2.Width = 115;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "CMND";
            this.columnHeader4.Width = 115;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Phòng";
            this.columnHeader3.Width = 73;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Số khách";
            this.columnHeader5.Width = 86;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Khách nước ngoài";
            this.columnHeader6.Width = 171;
            // 
            // btnTimPhieuThue
            // 
            this.btnTimPhieuThue.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(161)))), ((int)(((byte)(130)))));
            this.btnTimPhieuThue.FlatAppearance.BorderSize = 0;
            this.btnTimPhieuThue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimPhieuThue.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimPhieuThue.ForeColor = System.Drawing.Color.White;
            this.btnTimPhieuThue.Location = new System.Drawing.Point(809, 142);
            this.btnTimPhieuThue.Margin = new System.Windows.Forms.Padding(4);
            this.btnTimPhieuThue.Name = "btnTimPhieuThue";
            this.btnTimPhieuThue.Size = new System.Drawing.Size(100, 46);
            this.btnTimPhieuThue.TabIndex = 105;
            this.btnTimPhieuThue.Text = "Tìm";
            this.btnTimPhieuThue.UseVisualStyleBackColor = false;
            this.btnTimPhieuThue.Click += new System.EventHandler(this.btnTimPhieuThue_Click);
            // 
            // rbtnMaPhieuThue
            // 
            this.rbtnMaPhieuThue.AutoSize = true;
            this.rbtnMaPhieuThue.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnMaPhieuThue.Location = new System.Drawing.Point(43, 107);
            this.rbtnMaPhieuThue.Margin = new System.Windows.Forms.Padding(4);
            this.rbtnMaPhieuThue.Name = "rbtnMaPhieuThue";
            this.rbtnMaPhieuThue.Size = new System.Drawing.Size(133, 23);
            this.rbtnMaPhieuThue.TabIndex = 104;
            this.rbtnMaPhieuThue.TabStop = true;
            this.rbtnMaPhieuThue.Text = "Mã phiếu thuê";
            this.rbtnMaPhieuThue.UseVisualStyleBackColor = true;
            // 
            // rbtnNgayThue
            // 
            this.rbtnNgayThue.AutoSize = true;
            this.rbtnNgayThue.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnNgayThue.Location = new System.Drawing.Point(43, 46);
            this.rbtnNgayThue.Margin = new System.Windows.Forms.Padding(4);
            this.rbtnNgayThue.Name = "rbtnNgayThue";
            this.rbtnNgayThue.Size = new System.Drawing.Size(104, 23);
            this.rbtnNgayThue.TabIndex = 103;
            this.rbtnNgayThue.TabStop = true;
            this.rbtnNgayThue.Text = "Ngày thuê";
            this.rbtnNgayThue.UseVisualStyleBackColor = true;
            // 
            // txtMaPhieuThue
            // 
            this.txtMaPhieuThue.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaPhieuThue.Location = new System.Drawing.Point(249, 106);
            this.txtMaPhieuThue.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaPhieuThue.Name = "txtMaPhieuThue";
            this.txtMaPhieuThue.Size = new System.Drawing.Size(148, 27);
            this.txtMaPhieuThue.TabIndex = 101;
            // 
            // tabHoaDon
            // 
            this.tabHoaDon.Controls.Add(this.cmbNamHD);
            this.tabHoaDon.Controls.Add(this.lblNamHD);
            this.tabHoaDon.Controls.Add(this.cmbThangHD);
            this.tabHoaDon.Controls.Add(this.lblThangHD);
            this.tabHoaDon.Controls.Add(this.cmbNgayHD);
            this.tabHoaDon.Controls.Add(this.lblNgayHD);
            this.tabHoaDon.Controls.Add(this.btnMenuHD);
            this.tabHoaDon.Controls.Add(this.btnThoatHD);
            this.tabHoaDon.Controls.Add(this.lsvDanhSachHoaDon);
            this.tabHoaDon.Controls.Add(this.btnTimHoaDon);
            this.tabHoaDon.Controls.Add(this.rbtnMaHoaDon);
            this.tabHoaDon.Controls.Add(this.rbtnNgayTra);
            this.tabHoaDon.Controls.Add(this.txtMaHoaDon);
            this.tabHoaDon.Location = new System.Drawing.Point(4, 28);
            this.tabHoaDon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabHoaDon.Name = "tabHoaDon";
            this.tabHoaDon.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabHoaDon.Size = new System.Drawing.Size(949, 597);
            this.tabHoaDon.TabIndex = 2;
            this.tabHoaDon.Text = "Tra cứu hoá đơn";
            this.tabHoaDon.UseVisualStyleBackColor = true;
            // 
            // cmbNamHD
            // 
            this.cmbNamHD.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbNamHD.FormattingEnabled = true;
            this.cmbNamHD.Items.AddRange(new object[] {
            "2018",
            "2019",
            "2020",
            "2021",
            "2022",
            "2023",
            "2024",
            "2025"});
            this.cmbNamHD.Location = new System.Drawing.Point(737, 44);
            this.cmbNamHD.Margin = new System.Windows.Forms.Padding(4);
            this.cmbNamHD.Name = "cmbNamHD";
            this.cmbNamHD.Size = new System.Drawing.Size(79, 27);
            this.cmbNamHD.TabIndex = 122;
            // 
            // lblNamHD
            // 
            this.lblNamHD.AutoSize = true;
            this.lblNamHD.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNamHD.Location = new System.Drawing.Point(677, 48);
            this.lblNamHD.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNamHD.Name = "lblNamHD";
            this.lblNamHD.Size = new System.Drawing.Size(42, 19);
            this.lblNamHD.TabIndex = 121;
            this.lblNamHD.Text = "Năm";
            // 
            // cmbThangHD
            // 
            this.cmbThangHD.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbThangHD.FormattingEnabled = true;
            this.cmbThangHD.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cmbThangHD.Location = new System.Drawing.Point(533, 44);
            this.cmbThangHD.Margin = new System.Windows.Forms.Padding(4);
            this.cmbThangHD.Name = "cmbThangHD";
            this.cmbThangHD.Size = new System.Drawing.Size(79, 27);
            this.cmbThangHD.TabIndex = 120;
            // 
            // lblThangHD
            // 
            this.lblThangHD.AutoSize = true;
            this.lblThangHD.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThangHD.Location = new System.Drawing.Point(459, 48);
            this.lblThangHD.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblThangHD.Name = "lblThangHD";
            this.lblThangHD.Size = new System.Drawing.Size(54, 19);
            this.lblThangHD.TabIndex = 119;
            this.lblThangHD.Text = "Tháng";
            // 
            // cmbNgayHD
            // 
            this.cmbNgayHD.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbNgayHD.FormattingEnabled = true;
            this.cmbNgayHD.Items.AddRange(new object[] {
            "--",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.cmbNgayHD.Location = new System.Drawing.Point(317, 44);
            this.cmbNgayHD.Margin = new System.Windows.Forms.Padding(4);
            this.cmbNgayHD.Name = "cmbNgayHD";
            this.cmbNgayHD.Size = new System.Drawing.Size(79, 27);
            this.cmbNgayHD.TabIndex = 118;
            // 
            // lblNgayHD
            // 
            this.lblNgayHD.AutoSize = true;
            this.lblNgayHD.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNgayHD.Location = new System.Drawing.Point(245, 48);
            this.lblNgayHD.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNgayHD.Name = "lblNgayHD";
            this.lblNgayHD.Size = new System.Drawing.Size(47, 19);
            this.lblNgayHD.TabIndex = 117;
            this.lblNgayHD.Text = "Ngày";
            // 
            // btnMenuHD
            // 
            this.btnMenuHD.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnMenuHD.FlatAppearance.BorderSize = 0;
            this.btnMenuHD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuHD.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuHD.ForeColor = System.Drawing.Color.Gray;
            this.btnMenuHD.Location = new System.Drawing.Point(45, 532);
            this.btnMenuHD.Margin = new System.Windows.Forms.Padding(4);
            this.btnMenuHD.Name = "btnMenuHD";
            this.btnMenuHD.Size = new System.Drawing.Size(168, 46);
            this.btnMenuHD.TabIndex = 116;
            this.btnMenuHD.Text = "Quay lại menu";
            this.btnMenuHD.UseVisualStyleBackColor = false;
            this.btnMenuHD.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnThoatHD
            // 
            this.btnThoatHD.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnThoatHD.FlatAppearance.BorderSize = 0;
            this.btnThoatHD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThoatHD.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoatHD.ForeColor = System.Drawing.Color.Gray;
            this.btnThoatHD.Location = new System.Drawing.Point(809, 532);
            this.btnThoatHD.Margin = new System.Windows.Forms.Padding(4);
            this.btnThoatHD.Name = "btnThoatHD";
            this.btnThoatHD.Size = new System.Drawing.Size(100, 46);
            this.btnThoatHD.TabIndex = 115;
            this.btnThoatHD.Text = "Thoát";
            this.btnThoatHD.UseVisualStyleBackColor = false;
            this.btnThoatHD.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // lsvDanhSachHoaDon
            // 
            this.lsvDanhSachHoaDon.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader10,
            this.columnHeader9,
            this.columnHeader11});
            this.lsvDanhSachHoaDon.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lsvDanhSachHoaDon.FullRowSelect = true;
            this.lsvDanhSachHoaDon.GridLines = true;
            this.lsvDanhSachHoaDon.Location = new System.Drawing.Point(45, 194);
            this.lsvDanhSachHoaDon.Margin = new System.Windows.Forms.Padding(4);
            this.lsvDanhSachHoaDon.MultiSelect = false;
            this.lsvDanhSachHoaDon.Name = "lsvDanhSachHoaDon";
            this.lsvDanhSachHoaDon.Size = new System.Drawing.Size(863, 315);
            this.lsvDanhSachHoaDon.TabIndex = 114;
            this.lsvDanhSachHoaDon.UseCompatibleStateImageBehavior = false;
            this.lsvDanhSachHoaDon.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Mã hoá đơn";
            this.columnHeader7.Width = 127;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Ngày thanh toán";
            this.columnHeader8.Width = 160;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "CMND";
            this.columnHeader10.Width = 108;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Phòng";
            this.columnHeader9.Width = 91;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Trị giá";
            this.columnHeader11.Width = 123;
            // 
            // btnTimHoaDon
            // 
            this.btnTimHoaDon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(161)))), ((int)(((byte)(130)))));
            this.btnTimHoaDon.FlatAppearance.BorderSize = 0;
            this.btnTimHoaDon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimHoaDon.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimHoaDon.ForeColor = System.Drawing.Color.White;
            this.btnTimHoaDon.Location = new System.Drawing.Point(809, 142);
            this.btnTimHoaDon.Margin = new System.Windows.Forms.Padding(4);
            this.btnTimHoaDon.Name = "btnTimHoaDon";
            this.btnTimHoaDon.Size = new System.Drawing.Size(100, 46);
            this.btnTimHoaDon.TabIndex = 113;
            this.btnTimHoaDon.Text = "Tìm";
            this.btnTimHoaDon.UseVisualStyleBackColor = false;
            this.btnTimHoaDon.Click += new System.EventHandler(this.btnTimHoaDon_Click);
            // 
            // rbtnMaHoaDon
            // 
            this.rbtnMaHoaDon.AutoSize = true;
            this.rbtnMaHoaDon.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnMaHoaDon.Location = new System.Drawing.Point(43, 107);
            this.rbtnMaHoaDon.Margin = new System.Windows.Forms.Padding(4);
            this.rbtnMaHoaDon.Name = "rbtnMaHoaDon";
            this.rbtnMaHoaDon.Size = new System.Drawing.Size(119, 23);
            this.rbtnMaHoaDon.TabIndex = 112;
            this.rbtnMaHoaDon.TabStop = true;
            this.rbtnMaHoaDon.Text = "Mã hoá đơn";
            this.rbtnMaHoaDon.UseVisualStyleBackColor = true;
            // 
            // rbtnNgayTra
            // 
            this.rbtnNgayTra.AutoSize = true;
            this.rbtnNgayTra.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnNgayTra.Location = new System.Drawing.Point(43, 46);
            this.rbtnNgayTra.Margin = new System.Windows.Forms.Padding(4);
            this.rbtnNgayTra.Name = "rbtnNgayTra";
            this.rbtnNgayTra.Size = new System.Drawing.Size(149, 23);
            this.rbtnNgayTra.TabIndex = 111;
            this.rbtnNgayTra.TabStop = true;
            this.rbtnNgayTra.Text = "Ngày thanh toán";
            this.rbtnNgayTra.UseVisualStyleBackColor = true;
            // 
            // txtMaHoaDon
            // 
            this.txtMaHoaDon.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaHoaDon.Location = new System.Drawing.Point(249, 105);
            this.txtMaHoaDon.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaHoaDon.Name = "txtMaHoaDon";
            this.txtMaHoaDon.Size = new System.Drawing.Size(148, 27);
            this.txtMaHoaDon.TabIndex = 110;
            // 
            // tabBaoCao
            // 
            this.tabBaoCao.Controls.Add(this.label6);
            this.tabBaoCao.Controls.Add(this.txtTongDoanhThu);
            this.tabBaoCao.Controls.Add(this.label2);
            this.tabBaoCao.Controls.Add(this.cmbNamBC);
            this.tabBaoCao.Controls.Add(this.lblNamBC);
            this.tabBaoCao.Controls.Add(this.cmbThangBC);
            this.tabBaoCao.Controls.Add(this.lblThangBC);
            this.tabBaoCao.Controls.Add(this.btnMenuBC);
            this.tabBaoCao.Controls.Add(this.btnThoatBC);
            this.tabBaoCao.Controls.Add(this.lsvDanhSachBaoCao);
            this.tabBaoCao.Controls.Add(this.btnTimBaoCao);
            this.tabBaoCao.Controls.Add(this.rbtnMaBaoCao);
            this.tabBaoCao.Controls.Add(this.rbtnThangBaoCao);
            this.tabBaoCao.Controls.Add(this.txtMaBaoCao);
            this.tabBaoCao.Location = new System.Drawing.Point(4, 28);
            this.tabBaoCao.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabBaoCao.Name = "tabBaoCao";
            this.tabBaoCao.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabBaoCao.Size = new System.Drawing.Size(949, 597);
            this.tabBaoCao.TabIndex = 3;
            this.tabBaoCao.Text = "Tra cứu báo cáo";
            this.tabBaoCao.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(866, 456);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 19);
            this.label6.TabIndex = 133;
            this.label6.Text = "VND";
            // 
            // txtTongDoanhThu
            // 
            this.txtTongDoanhThu.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTongDoanhThu.Location = new System.Drawing.Point(670, 452);
            this.txtTongDoanhThu.Margin = new System.Windows.Forms.Padding(4);
            this.txtTongDoanhThu.Name = "txtTongDoanhThu";
            this.txtTongDoanhThu.ReadOnly = true;
            this.txtTongDoanhThu.Size = new System.Drawing.Size(188, 27);
            this.txtTongDoanhThu.TabIndex = 132;
            this.txtTongDoanhThu.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(520, 456);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 19);
            this.label2.TabIndex = 131;
            this.label2.Text = "Tổng doanh thu";
            // 
            // cmbNamBC
            // 
            this.cmbNamBC.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbNamBC.FormattingEnabled = true;
            this.cmbNamBC.Items.AddRange(new object[] {
            "2018",
            "2019",
            "2020",
            "2021",
            "2022",
            "2023",
            "2024",
            "2025"});
            this.cmbNamBC.Location = new System.Drawing.Point(524, 44);
            this.cmbNamBC.Margin = new System.Windows.Forms.Padding(4);
            this.cmbNamBC.Name = "cmbNamBC";
            this.cmbNamBC.Size = new System.Drawing.Size(79, 27);
            this.cmbNamBC.TabIndex = 130;
            // 
            // lblNamBC
            // 
            this.lblNamBC.AutoSize = true;
            this.lblNamBC.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNamBC.Location = new System.Drawing.Point(464, 48);
            this.lblNamBC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNamBC.Name = "lblNamBC";
            this.lblNamBC.Size = new System.Drawing.Size(42, 19);
            this.lblNamBC.TabIndex = 129;
            this.lblNamBC.Text = "Năm";
            // 
            // cmbThangBC
            // 
            this.cmbThangBC.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbThangBC.FormattingEnabled = true;
            this.cmbThangBC.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cmbThangBC.Location = new System.Drawing.Point(320, 44);
            this.cmbThangBC.Margin = new System.Windows.Forms.Padding(4);
            this.cmbThangBC.Name = "cmbThangBC";
            this.cmbThangBC.Size = new System.Drawing.Size(79, 27);
            this.cmbThangBC.TabIndex = 128;
            // 
            // lblThangBC
            // 
            this.lblThangBC.AutoSize = true;
            this.lblThangBC.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThangBC.Location = new System.Drawing.Point(245, 48);
            this.lblThangBC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblThangBC.Name = "lblThangBC";
            this.lblThangBC.Size = new System.Drawing.Size(54, 19);
            this.lblThangBC.TabIndex = 127;
            this.lblThangBC.Text = "Tháng";
            // 
            // btnMenuBC
            // 
            this.btnMenuBC.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnMenuBC.FlatAppearance.BorderSize = 0;
            this.btnMenuBC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuBC.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuBC.ForeColor = System.Drawing.Color.Gray;
            this.btnMenuBC.Location = new System.Drawing.Point(45, 532);
            this.btnMenuBC.Margin = new System.Windows.Forms.Padding(4);
            this.btnMenuBC.Name = "btnMenuBC";
            this.btnMenuBC.Size = new System.Drawing.Size(168, 46);
            this.btnMenuBC.TabIndex = 124;
            this.btnMenuBC.Text = "Quay lại menu";
            this.btnMenuBC.UseVisualStyleBackColor = false;
            this.btnMenuBC.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnThoatBC
            // 
            this.btnThoatBC.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnThoatBC.FlatAppearance.BorderSize = 0;
            this.btnThoatBC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThoatBC.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoatBC.ForeColor = System.Drawing.Color.Gray;
            this.btnThoatBC.Location = new System.Drawing.Point(809, 532);
            this.btnThoatBC.Margin = new System.Windows.Forms.Padding(4);
            this.btnThoatBC.Name = "btnThoatBC";
            this.btnThoatBC.Size = new System.Drawing.Size(100, 46);
            this.btnThoatBC.TabIndex = 123;
            this.btnThoatBC.Text = "Thoát";
            this.btnThoatBC.UseVisualStyleBackColor = false;
            this.btnThoatBC.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // lsvDanhSachBaoCao
            // 
            this.lsvDanhSachBaoCao.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader12,
            this.columnHeader14,
            this.columnHeader13,
            this.columnHeader15,
            this.columnHeader16});
            this.lsvDanhSachBaoCao.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lsvDanhSachBaoCao.FullRowSelect = true;
            this.lsvDanhSachBaoCao.GridLines = true;
            this.lsvDanhSachBaoCao.Location = new System.Drawing.Point(43, 207);
            this.lsvDanhSachBaoCao.Margin = new System.Windows.Forms.Padding(4);
            this.lsvDanhSachBaoCao.MultiSelect = false;
            this.lsvDanhSachBaoCao.Name = "lsvDanhSachBaoCao";
            this.lsvDanhSachBaoCao.Size = new System.Drawing.Size(863, 229);
            this.lsvDanhSachBaoCao.TabIndex = 122;
            this.lsvDanhSachBaoCao.UseCompatibleStateImageBehavior = false;
            this.lsvDanhSachBaoCao.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Mã báo cáo";
            this.columnHeader12.Width = 121;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Loại phòng";
            this.columnHeader14.Width = 125;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Tháng báo cáo";
            this.columnHeader13.Width = 111;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Doanh thu (VNĐ)";
            this.columnHeader15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader15.Width = 156;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Tỉ lệ";
            this.columnHeader16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader16.Width = 74;
            // 
            // btnTimBaoCao
            // 
            this.btnTimBaoCao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(161)))), ((int)(((byte)(130)))));
            this.btnTimBaoCao.FlatAppearance.BorderSize = 0;
            this.btnTimBaoCao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimBaoCao.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimBaoCao.ForeColor = System.Drawing.Color.White;
            this.btnTimBaoCao.Location = new System.Drawing.Point(809, 142);
            this.btnTimBaoCao.Margin = new System.Windows.Forms.Padding(4);
            this.btnTimBaoCao.Name = "btnTimBaoCao";
            this.btnTimBaoCao.Size = new System.Drawing.Size(100, 46);
            this.btnTimBaoCao.TabIndex = 121;
            this.btnTimBaoCao.Text = "Tìm";
            this.btnTimBaoCao.UseVisualStyleBackColor = false;
            this.btnTimBaoCao.Click += new System.EventHandler(this.btnTimBaoCao_Click);
            // 
            // rbtnMaBaoCao
            // 
            this.rbtnMaBaoCao.AutoSize = true;
            this.rbtnMaBaoCao.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnMaBaoCao.Location = new System.Drawing.Point(43, 107);
            this.rbtnMaBaoCao.Margin = new System.Windows.Forms.Padding(4);
            this.rbtnMaBaoCao.Name = "rbtnMaBaoCao";
            this.rbtnMaBaoCao.Size = new System.Drawing.Size(116, 23);
            this.rbtnMaBaoCao.TabIndex = 120;
            this.rbtnMaBaoCao.TabStop = true;
            this.rbtnMaBaoCao.Text = "Mã báo cáo";
            this.rbtnMaBaoCao.UseVisualStyleBackColor = true;
            // 
            // rbtnThangBaoCao
            // 
            this.rbtnThangBaoCao.AutoSize = true;
            this.rbtnThangBaoCao.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnThangBaoCao.Location = new System.Drawing.Point(43, 46);
            this.rbtnThangBaoCao.Margin = new System.Windows.Forms.Padding(4);
            this.rbtnThangBaoCao.Name = "rbtnThangBaoCao";
            this.rbtnThangBaoCao.Size = new System.Drawing.Size(139, 23);
            this.rbtnThangBaoCao.TabIndex = 119;
            this.rbtnThangBaoCao.TabStop = true;
            this.rbtnThangBaoCao.Text = "Tháng báo cáo";
            this.rbtnThangBaoCao.UseVisualStyleBackColor = true;
            // 
            // txtMaBaoCao
            // 
            this.txtMaBaoCao.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaBaoCao.Location = new System.Drawing.Point(249, 105);
            this.txtMaBaoCao.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaBaoCao.Name = "txtMaBaoCao";
            this.txtMaBaoCao.Size = new System.Drawing.Size(148, 27);
            this.txtMaBaoCao.TabIndex = 118;
            // 
            // TraCuu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(982, 768);
            this.Controls.Add(this.tabTraCuu);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "TraCuu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tra cứu";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.DanhSachPhong_FormClosed);
            this.tabTraCuu.ResumeLayout(false);
            this.tabPhong.ResumeLayout(false);
            this.tabPhong.PerformLayout();
            this.tabPhieuThue.ResumeLayout(false);
            this.tabPhieuThue.PerformLayout();
            this.tabHoaDon.ResumeLayout(false);
            this.tabHoaDon.PerformLayout();
            this.tabBaoCao.ResumeLayout(false);
            this.tabBaoCao.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabTraCuu;
        private System.Windows.Forms.TabPage tabPhong;
        private System.Windows.Forms.ComboBox cmbLoaiPhong;
        private System.Windows.Forms.Button btnTimPhong;
        private System.Windows.Forms.ComboBox cmbTinhTrang;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListView lsvDanhSachPhong;
        private System.Windows.Forms.ColumnHeader clnPhong;
        private System.Windows.Forms.ColumnHeader clnLoaiPhong;
        private System.Windows.Forms.ColumnHeader clnDonGia;
        private System.Windows.Forms.ColumnHeader clnTinhTrang;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnThuePhong;
        private System.Windows.Forms.TabPage tabPhieuThue;
        private System.Windows.Forms.TabPage tabHoaDon;
        private System.Windows.Forms.TabPage tabBaoCao;
        private System.Windows.Forms.TextBox txtMaPhieuThue;
        private System.Windows.Forms.RadioButton rbtnMaPhieuThue;
        private System.Windows.Forms.RadioButton rbtnNgayThue;
        private System.Windows.Forms.ListView lsvDanhSachPhieuThue;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Button btnTimPhieuThue;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Button btnMenuPT;
        private System.Windows.Forms.Button btnThoatPT;
        private System.Windows.Forms.Button btnMenuHD;
        private System.Windows.Forms.Button btnThoatHD;
        private System.Windows.Forms.ListView lsvDanhSachHoaDon;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.Button btnTimHoaDon;
        private System.Windows.Forms.RadioButton rbtnMaHoaDon;
        private System.Windows.Forms.RadioButton rbtnNgayTra;
        private System.Windows.Forms.TextBox txtMaHoaDon;
        private System.Windows.Forms.Button btnMenuBC;
        private System.Windows.Forms.Button btnThoatBC;
        private System.Windows.Forms.ListView lsvDanhSachBaoCao;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.Button btnTimBaoCao;
        private System.Windows.Forms.RadioButton rbtnMaBaoCao;
        private System.Windows.Forms.RadioButton rbtnThangBaoCao;
        private System.Windows.Forms.TextBox txtMaBaoCao;
        private System.Windows.Forms.ComboBox cmbNamPT;
        private System.Windows.Forms.Label lblNamPT;
        private System.Windows.Forms.ComboBox cmbThangPT;
        private System.Windows.Forms.Label lblThangPT;
        private System.Windows.Forms.ComboBox cmbNgayPT;
        private System.Windows.Forms.Label lblNgayPT;
        private System.Windows.Forms.ComboBox cmbNamHD;
        private System.Windows.Forms.Label lblNamHD;
        private System.Windows.Forms.ComboBox cmbThangHD;
        private System.Windows.Forms.Label lblThangHD;
        private System.Windows.Forms.ComboBox cmbNgayHD;
        private System.Windows.Forms.Label lblNgayHD;
        private System.Windows.Forms.ComboBox cmbNamBC;
        private System.Windows.Forms.Label lblNamBC;
        private System.Windows.Forms.ComboBox cmbThangBC;
        private System.Windows.Forms.Label lblThangBC;
        private System.Windows.Forms.TextBox txtTongDoanhThu;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
    }
}